// Import required libraries
const express = require('express');
const axios = require('axios');
const cors = require('cors');
const path = require('path');

// Initialize the Express app
const app = express();

// Enable CORS to allow frontend to access the backend
app.use(cors());

// Define the port number
const port = 3001;

// Sample route to handle API requests for dog facts
app.get('/dog-facts', async (req, res) => {
    try {
        // Fetch random dog facts from the Dog API
        const response = await axios.get('https://dog-api.kinduff.com/api/facts');

        // Return the fetched dog facts as a JSON response
        res.json({
            facts: response.data.facts
        });
    } catch (error) {
        console.error('Error fetching dog facts:', error);
        res.status(500).json({ error: 'Failed to fetch dog facts' });
    }
});

// Serve static files for the frontend (optional, if serving from the same server)
const distPath = path.join(__dirname, '../frontend/dist');  // Correct path to the dist folder

app.use(express.static(distPath));

// Catch-all route to handle all frontend routes (for single-page apps)
app.get('*', (req, res) => {
    res.sendFile(path.join(distPath, 'index.html'));  // Correct path to the index.html file
});

// Start the server and listen on the specified port
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
